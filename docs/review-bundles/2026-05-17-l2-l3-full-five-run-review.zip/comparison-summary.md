# L2/L3 Five-Run Comparison

| run | avg_quality | hard pass | green | yellow | red | L4 forward | candidates | API calls | provider errors |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| initial | 0.967 | 9/20 | 9 | 8 | 3 | 17 | 20 | 20 | 0 |
| strong_constraints | 0.932 | 4/20 | 4 | 8 | 8 | 12 | 20 | 20 | 0 |
| relaxed_judgment | 0.752 | 0/20 | 0 | 0 | 20 | 0 | 20 | 20 | 0 |
| light_single | 0.979 | 10/20 | 10 | 8 | 2 | 18 | 20 | 20 | 0 |
| multi3 | 0.975 | 6/20 | 6 | 12 | 2 | 18 | 60 | 20 | 0 |

## Green Pool

| run | green_count | avg_quality | avg_actionable | avg_weak | avg_specificity |
| --- | ---: | ---: | ---: | ---: | ---: |
| initial | 9 | 1 | 5 | 0 | 11.667 |
| strong_constraints | 4 | 1 | 5.25 | 0 | 10.25 |
| relaxed_judgment | 0 | null | null | null | null |
| light_single | 10 | 1 | 5 | 0 | 12.6 |
| multi3 | 6 | 1 | 4.833 | 0 | 8.667 |

## Yellow Pool

| run | yellow_count | avg_quality | avg_actionable | avg_weak | avg_specificity |
| --- | ---: | ---: | ---: | ---: | ---: |
| initial | 8 | 0.978 | 4.125 | 0.875 | 11.875 |
| strong_constraints | 8 | 0.972 | 4 | 1.125 | 10.625 |
| relaxed_judgment | 0 | null | null | null | null |
| light_single | 8 | 0.975 | 4.125 | 1 | 11.125 |
| multi3 | 12 | 0.975 | 4 | 1 | 9.083 |

## Short Read

- light_single is the best current default: highest avg quality, most green, clean red count.
- multi3 proves candidate-pool mechanics: 60 candidates from 20 API calls, selected best candidate in all 20 samples.
- multi3 is not yet the default: green drops and yellow expands, so L4 gets more coverage but more review load.
- strong_constraints and relaxed_judgment are retained as negative evidence for prompt tuning.
