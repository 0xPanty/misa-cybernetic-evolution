# Pro Review Notes: L2/L3 Five-Run Test

## Context

This bundle compares five L2/L3 runs on the same 20 slim SWE-rebench online-shadow samples:

- `initial`: original Hermes delegate single-candidate L2.
- `strong-constraints`: heavier engineering checklist prompt. Negative evidence.
- `relaxed-judgment`: looser LLM judgment prompt. Negative evidence.
- `light-single`: lightly tuned prompt, still one L2 draft per sample. Current best default.
- `multi3`: one Hermes delegate API call per sample, three candidates per call, local L2 gate selects one winner, then L3 pools the selected winner.

All runs are observe-only. No memory write, Zilliz write, embedding creation, route change, winner authority change, work-order execution, VPS production change, GitHub push, or public publish is allowed by the tested path.

## Key Numbers

| run | avg_quality | hard pass | green | yellow | red | L4 forward | candidates | API calls |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| initial | 0.967 | 9/20 | 9 | 8 | 3 | 17 | 20 | 20 |
| strong-constraints | 0.932 | 4/20 | 4 | 8 | 8 | 12 | 20 | 20 |
| relaxed-judgment | 0.752 | 0/20 | 0 | 0 | 20 | 0 | 20 | 20 |
| light-single | 0.979 | 10/20 | 10 | 8 | 2 | 18 | 20 | 20 |
| multi3 | 0.975 | 6/20 | 6 | 12 | 2 | 18 | 60 | 20 |

Multi3 generated 60 candidates with 20 API calls. L2 selected a winner for all 20 samples. L3 reports `candidate_best_found_count=20`, meaning the selected winner matched the highest local gate score among the three candidates for every sample.

## Current Interpretation

The L3 route looks viable. Green/yellow/red works as a lightweight ledger between L2 generation and L4 primary-agent review.

`light-single` is the best stable default so far. It has the highest average quality, the most green items, and a clean red count.

The multi-candidate pool mechanism appears valid: it can surface better candidates without increasing API calls, and local winner selection can find the best scored candidate inside each sample's pool. It is not yet the default because the current multi-candidate prompt expands yellow and lowers green count, increasing L4 review load.

The prompt tests provide negative evidence:

- `strong-constraints` overfits the checklist and reduces pass quality.
- `relaxed-judgment` becomes too soft and fails the gate entirely.
- `light-single` is the best stable default.
- `multi3` should remain an explicit exploration/recheck mode until the candidate prompt is tighter.

## Questions For Pro

1. Is L3's green/yellow/red ledger a reasonable bridge between L2 candidate generation and L4 primary-agent review?
2. Should multi-candidate mode remain an explicit exploration mode such as `--candidate-count 3`?
3. Is the right next optimization prompt-level tightening rather than adding another deterministic governance layer?
4. Should L3 score the selected winner only, or should it also expose candidate-level diversity and loser evidence more directly to L4?
5. What prompt wording best keeps all three candidates independently gate-passable while still meaningfully different?

## Suggested Prompt Direction

Keep multi-candidate generation, but tighten the prompt:

- All candidates must be independently gate-passable.
- Difference is focus only, not strictness.
- Do not diversify by becoming broader, softer, or more abstract.
- Every candidate must include exact file/test target, source_id or signal/evidence ref, field/boundary, and explicit expected result.
- LLM does not choose the winner. Local scoring chooses the winner; losers are evidence only.

## Files

- `sample/online-shadow-report.sample20.json`: original 20-sample input.
- `01-initial/`: original single-candidate L2/L3 reports.
- `02-strong-constraints/`: heavier prompt negative-evidence L2/L3 reports.
- `03-relaxed-judgment/`: looser prompt negative-evidence L2/L3 reports.
- `04-light-single/`: lightly tuned single-candidate L2/L3 reports.
- `05-multi3/`: three-candidate L2/L3 reports, command, stdout.
- `comparison-summary.json`: structured comparison.
- `comparison-summary.md`: compact comparison table.
